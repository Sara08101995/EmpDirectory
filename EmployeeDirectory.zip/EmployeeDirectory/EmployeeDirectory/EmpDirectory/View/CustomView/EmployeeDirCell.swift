//
//  EmployeeDirCell.swift
//  EmployeeDirectory
//
//  Created by Saravanan Palanisamy on 23/07/22.
//

import Foundation
import UIKit

class EmployeeDirCell: UITableViewCell {
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var companyName: UILabel!
}
