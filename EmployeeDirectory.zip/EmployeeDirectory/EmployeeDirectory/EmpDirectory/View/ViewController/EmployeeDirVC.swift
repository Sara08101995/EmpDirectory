//
//  EmployeeDirVC.swift
//  EmployeeDirectory
//
//  Created by Saravanan Palanisamy on 23/07/22.
//

import UIKit

class EmployeeDirVC: UIViewController {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var employeeDirVM: EmployeeDirVM? = nil
    var employeeDirModel : [EmployeeDirModel]? = [EmployeeDirModel()]
    var arrayOfImageURL = [String]()
    var photos: [PhotoRecord] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.employeeDirVM = EmployeeDirVM(employeeDirService: EmployeeDirService())
        
        self.callAPI()
        // Do any additional setup after loading the view.
    }
    
    func callAPI() {
        self.employeeDirVM?.getEmployeeDetails(handler: { model in
            DispatchQueue.main.async {
                guard let model = model  else { return }
                self.employeeDirModel = model
                self.arrayOfImageURL = model.map{$0.profile_image ?? "https://www.vecteezy.com/free-vector/exclamation-icon"}
                let _ = self.arrayOfImageURL.map { urlString in
                    guard let url = URL(string: urlString) else { return }
                    self.photos.append(PhotoRecord(url: url, state: "new"))
                }
                self.tableView.reloadData()
            }
        })
    }
}


extension  EmployeeDirVC:  UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.employeeDirModel?.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if var cell: EmployeeDirCell = tableView.dequeueReusableCell(withIdentifier: "employeeCell") as? EmployeeDirCell {
            if self.photos.count > 0 && indexPath.row != self.photos.count {
            cell.profileImage.image = self.photos[indexPath.row].image
            switch (self.photos[indexPath.row].state) {
            case "new":
                operationQueue(indexPath: indexPath)
            case "Success", "Failed":
                cell.profileImage.image = self.photos[indexPath.row].image
                
            default:
                cell.profileImage.image = self.photos[indexPath.row].image
            }
            }
            
            cell.name.text = self.employeeDirModel?[indexPath.row].name ?? ""
            cell.companyName.text = self.employeeDirModel?[indexPath.row].company?.name ?? ""
            return cell
        }
        
        return UITableViewCell()
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "EmployeeDetailsVC") as? EmployeeDetailsVC {
            vc.employeeDirModel = self.employeeDirModel?[indexPath.row] ?? nil
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
}

extension EmployeeDirVC {  //Operation Queue
    func operationQueue(indexPath: IndexPath) {
        let queue = OperationQueue()
        //queue.maxConcurrentOperationCount = 1 //call one by one
        let contentImportOperation = ContentImportOperation(photoRecord: self.photos[indexPath.row])
            
            contentImportOperation.completionBlock = {
                DispatchQueue.main.async {
                    self.tableView.reloadRows(at: [indexPath], with: .fade)
                }
            }
            queue.addOperation(contentImportOperation)
    }
    
    class ContentImportOperation: Operation {
        
        let photoRecord : PhotoRecord
        
        init(photoRecord: PhotoRecord) {
            self.photoRecord = photoRecord
            super.init()
        }
        
        override func main() {
            if isCancelled {
                return
            }
            
            
            URLSession.shared.dataTask(with: URLRequest(url: photoRecord.url)) { data, response, error in
                guard let imageData = data else {
                    self.photoRecord.image = UIImage(named: "Failed")
                    self.photoRecord.state = "Failed"
                    return
                }
                if imageData.isEmpty {
                    self.photoRecord.image = UIImage(named: "Failed")
                    self.photoRecord.state = "Failed"
                } else {
                    self.photoRecord.image = UIImage(data: imageData)
                    self.photoRecord.state = "Success"
                }
            }.resume()
            
          
        }
    }
}



class PhotoRecord {
    var image = UIImage(named: "Placeholder")
    let url: URL
    var state: String
    
    init(url:URL, state: String) {
        self.url = url
        self.state = state
    }
}
