//
//  EmployeeDetailsVC.swift
//  EmployeeDirectory
//
//  Created by Saravanan Palanisamy on 23/07/22.
//

import UIKit

class EmployeeDetailsVC: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var comapnyLabel: UILabel!
    
    var employeeDirModel : EmployeeDirModel?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateView()

    }
    

    func updateView() {
        guard let employeeDirModel = self.employeeDirModel else { return }
        self.nameLabel.text = employeeDirModel.name ?? ""
        self.emailLabel.text = employeeDirModel.email ?? ""
        if let address = employeeDirModel.address {
            let fullAddress = "\(address.street ?? "") \(address.city ?? "")  \(address.zipcode ?? "")"
            self.addressLabel.text = fullAddress
        }
        self.comapnyLabel.text = employeeDirModel.company?.name ?? ""
    }

}
