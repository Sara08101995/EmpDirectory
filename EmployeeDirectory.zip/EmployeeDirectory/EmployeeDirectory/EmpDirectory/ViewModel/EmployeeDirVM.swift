//
//  EmployeeDirVM.swift
//  EmployeeDirectory
//
//  Created by Saravanan Palanisamy on 23/07/22.
//

import Foundation
import CoreData
import UIKit

class EmployeeDirVM {
    
    let employeeDirService : EmployeeDirService?
    
    init(employeeDirService: EmployeeDirService) {
        self.employeeDirService = employeeDirService
    }
    
    func getEmployeeDetails( handler: @escaping (([EmployeeDirModel]?)->Void))  {
        if let data = self.getEmployeeList() {
            self.convertToDictionary(data: data, handler: { model in
                handler(model)
            })
        } else {
            self.employeeDirService?.callAPI(handler: { data in
                DispatchQueue.main.async {
                    guard let data = data  else {
                        handler(nil)
                        return
                    }
                    self.storeCoreData(data: data, handler: { model in
                        handler(model)
                    })
                }
            })
        }
    }
    
    func storeCoreData(data: Data, handler: @escaping (([EmployeeDirModel]?)->Void)) {
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appdelegate.persistentContainer.viewContext
        guard let entity = NSEntityDescription.entity(forEntityName: "Employees", in: managedContext) else { return  }
        
        let managedObject = NSManagedObject(entity: entity, insertInto: managedContext)
        managedObject.setValue(data, forKey: "details")
        self.convertToDictionary(data: data, handler: { model in
            handler(model)
        })
        
        do {
            try managedContext.save()
        } catch let error as NSError {
            print(error.debugDescription)
        }
    }
    
    func convertToDictionary(data: Data, handler: @escaping (([EmployeeDirModel]?)->Void)) {
        do {
             let decoder = JSONDecoder()
            let employeeDirModel = try decoder.decode([EmployeeDirModel].self, from: data)
            handler(employeeDirModel)
        } catch {
            print(error)
            handler(nil)
        }
    }
    
    
    func getEmployeeList() -> Data? {
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else { return nil}
        let managedContext = appdelegate.persistentContainer.viewContext
        let fetchRequest  = NSFetchRequest<NSManagedObject>.init(entityName: "Employees")
        do {
            let value = try managedContext.fetch(fetchRequest)
            if let data = value.first?.value(forKey: "details") as? Data {
                return data
                //print(String(data: data, encoding: .utf8))
            }
        } catch let error as NSError {
            return nil
        }
        return nil
    }
    
    
}
