//
//  EmployeeDirModel.swift
//  EmployeeDirectory
//
//  Created by Saravanan Palanisamy on 23/07/22.
//

import Foundation

struct EmployeeDirModel : Codable {
    
    var id: Int?
    var name: String?
    var username: String?
    var email: String?
    var profile_image: String?
    var address: Address?
    var phone: String?
    var company: Company?
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case name = "name"
        case username = "username"
        case email = "email"
        case profile_image = "profile_image"
        case address = "address"
        case phone = "phone"
        case company = "company"
    }
}


struct Address: Codable {
    var street: String?
    var city: String?
    var zipcode: String?
    
    enum CodingKeys: String, CodingKey {
        case street = "street"
        case city = "city"
        case zipcode = "zipcode"
    }
}


struct Company: Codable {
    var name: String?
    
    enum CodingKeys: String, CodingKey {
        case name = "name"
    }
}
