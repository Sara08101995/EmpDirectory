//
//  EmployeeDirService.swift
//  EmployeeDirectory
//
//  Created by Saravanan Palanisamy on 23/07/22.
//

import Foundation


class EmployeeDirService {
    
    func callAPI( handler: @escaping ((Data?)->Void))  {
        let urlString = "https://www.mocky.io/v2/5d565297300000680030a986"
        guard let url = URL(string: urlString) else {
            handler(nil)
            return
        }
        let urlRequest = URLRequest(url: url)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                guard let data = data else {
                    handler(nil)
                    return
                }
            handler(data)
            
        }
        task.resume()
    }

    
}
